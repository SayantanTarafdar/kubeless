'use strict';

module.exports = {
    main:function (event, context) {
    	console.log("hello world");
    }
}
