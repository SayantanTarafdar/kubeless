'use strict';
var request = require('request');
var fs = require('fs')
    , path = require('path');
var certData=
`-----BEGIN CERTIFICATE-----
MIIDpzCCAo+gAwIBAgIEI5sjHTANBgkqhkiG9w0BAQsFADBsMRAwDgYDVQQGEwdV
bmtub3duMRAwDgYDVQQIEwdVbmtub3duMRAwDgYDVQQHEwdVbmtub3duMRAwDgYD
VQQKEwdVbmtub3duMRAwDgYDVQQLEwdVbmtub3duMRAwDgYDVQQDEwdVbmtub3du
MB4XDTE5MDExNTEzNTQ1N1oXDTE5MDQxNTEzNTQ1N1owbDEQMA4GA1UEBhMHVW5r
bm93bjEQMA4GA1UECBMHVW5rbm93bjEQMA4GA1UEBxMHVW5rbm93bjEQMA4GA1UE
ChMHVW5rbm93bjEQMA4GA1UECxMHVW5rbm93bjEQMA4GA1UEAxMHVW5rbm93bjCC
ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALEAA68zK5nUDogTwVdUMvvq
7Si8yagsG44+g1KtnvccmrjCe+0gWOaxhQ0Mcq9Oze6g9CpSK3iOl3RJMBh+F6ox
EYY6C78PQSFQ+5qdmbKJydAT3dCu+bI2j0MY3Q9Cj+PNzQ8bNM8SGprcbTmT22Qt
tZj9xVTTc04g/AtQfMGPaFMGuUioqUSfXj+X1JTTgNNca2ldPiv7f1pxQR2sMW6d
j1QiCyCQYU4lf0MWmv7AstNJAecwD936UtXLJ9dkNxbDDUYUjOHQzHKOqM88fjZ2
aGsPiFNvtWG8oxiABO0F2zeS6T5yyjtGqMI+OgOQ/oM1ytA20yYg7aYF6KqeCskC
AwEAAaNRME8wLgYDVR0RBCcwJYIdc2ludi1oeWJyaXMxLmlzbC5lZHN0LmlibS5j
b22HBApBoOowHQYDVR0OBBYEFNDR2OtNLlOy30kFKmqF90If2qGSMA0GCSqGSIb3
DQEBCwUAA4IBAQCVemAFMkiamkSUE8TaswUBTyIVfQQVEkNftkzm2vzDvI4KnMvk
2g2SRLYV+zWV+lsln0IZnsyHzH3DpdmuVze+HY6SK5W0p2wMwEyYzHPAHNBfZsDm
DZHU4CpoZYvr+DSJNCcS3rN7Yzj4fHujQAsLT3A+C86cy6YeruRfExvnMJBXuHeS
EE1lsHTywYLqysvIM2FiHprEhS8INhW5dGjlDWzvUpT0LZyRlQJ4S/SgWQyIXK1D
/9dyMAvMAI/YaSKf2dpzWInb/vimepDV4Cdyhzf1wR3sW1VqFQyLLZiZ8H6LqtQS
bGiGAQqJ3Cfrxo7pQ4fFaeUFWqApersmocKI
-----END CERTIFICATE-----`;
fs.appendFile(__dirname+'/tls_cert1.pem', certData, function (err) {
  if (err) throw err;
  console.log('Saved!');
})



module.exports = {
    handler:function (event, context) {
    	var ca = path.resolve(__dirname, 'tls_cert1.pem');
    	var options={
          headers:{
            'User-Agent':'Chrome/59.0.3071.115'
          },
          url:'https://10.65.160.234:9002/rest/v2/apparel-uk/countries?type=SHIPPING&fields=DEFAULT',
          ca: fs.readFileSync(ca)
        };
        request(options, function (error, response, body) {
	        console.log('error:', error); // Print the error if one occurred
	        console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
	        console.log('body:', body); // Print the HTML for the Google homepage.
        });
    }
}
