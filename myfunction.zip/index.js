'use strict';

module.exports = {
    handler:function (event, context) {
    	console.log("hello world");
    }
}
