'use strict';
var request = require('request');
var fs = require('fs')
    , path = require('path');
var ca = path.resolve(__dirname, 'tls_cert.pem');

module.exports = {
    handler:function (event, context) {
    	var options={
          headers:{
            'User-Agent':'Chrome/59.0.3071.115'
          },
          url:'https://10.65.160.234:9002/rest/v2/apparel-uk/countries?type=SHIPPING&fields=DEFAULT',
          ca: fs.readFileSync(ca)
        };
        request(options, function (error, response, body) {
	        console.log('error:', error); // Print the error if one occurred
	        console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
	        console.log('body:', body); // Print the HTML for the Google homepage.
        });
    }
}
